#include<stdio.h>
#include<stdlib.h>
#include<time.h>


void swap(int *a,int *b)
{
	int t=*a;
	*a=*b;
	*b=t;
}

int part(int a[],int p,int r)
{
	int i=p-1,j;


	int m=(p+r)/2;

	//taking median of 3 element as pivot

	if(a[m]<a[p])
	{
		swap(&a[m],&a[p]);
	}

	if(a[r]<a[p])
	{
		swap(&a[r],&a[p]);
	}


	if(a[r]<a[m])
	{
		swap(&a[r],&a[m]);
	}

	int x=a[m];
	swap(&a[m],&a[r]);

	for(j=p;j<r;j++)
	{
		if(a[j]<=x)
		{
			i++;
			swap(&a[i],&a[j]);

		}
	}
	swap(&a[i+1],&a[r]);
	return i+1;
}

int rpart(int a[],int p,int r)
{
	srand( time(NULL));
	int j=rand()%(r-p+1) + p;
	swap(&a[r],&a[j]);     // randomising index of array element so that we can take median of 1st,mid and last element and they 3 will become random as well
	return part(a,p,r);


} 

void quicksort(int a[],int p,int r)
{
	while(p<r)
	{

		int q=rpart(a,p,r);
		if((q-1-p)<(r-q-1))
		{
			quicksort(a,p,q-1);
			p=q+1;
		}

		else
		{
			quicksort(a,q+1,r);
			r=q-1;
		}
	}
}

int main()
{
	int n,i;
	printf("enter the num of elements");
	scanf("%d",&n);

	int a[n];
	printf("enter the array elements");
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}

	quicksort(a,0,n-1);

	printf("sorted array");
	for(i=0;i<n;i++)
	{
		printf("%d",a[i]);
		printf("\n");
	}
	return 0;
}                         
