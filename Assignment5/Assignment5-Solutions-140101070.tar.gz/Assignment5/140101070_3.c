#include<stdio.h>
#include<string.h>


int main()
{
int n,i,j;
scanf("%d",&n);

char a[n][6];

for(i=0;i<n;i++)
{
scanf("%s",&a[i][6]);

}

/*
for(i=0;i<n;i++)
{
printf("%s",&a[i][5]);
printf("\n");
}
*/

char k[6];
printf("enter the element for comparing");
scanf("%s",&k[6]);

for(i=0;i<n;i++)
{
if(strcmp(&k[6],&a[i][6])>0)
{
printf("larger ele= ");
printf("%s \n",&a[i][6]);
}
else
if(strcmp(&k[6],&a[i][6])<0)
{
printf("smaller ele= ");
printf("%s \n",&a[i][6]);
}
}

return 0;
}
