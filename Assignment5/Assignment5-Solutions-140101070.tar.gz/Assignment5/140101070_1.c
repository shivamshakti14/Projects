#include<stdio.h>
void swap(int *a,int *b)
{
	int t=*a;
	*a=*b;
	*b=t;
}

int part(int a[],int p,int r)
{
	int i=p,j,x=a[p];

	//taking first element as pivot
	for(j=p+1;j<=r;j++)
	{
		if(a[j]<=x)
		{

			swap(&a[i],&a[j]);
			i++;
		}
	}
	swap(&a[i-1],&a[p]);
	return i;
}

void quicksort(int a[],int p,int r)
{
	if(p<r)
	{
		int q=part(a,p,r);
		quicksort(a,p,q-1);
		quicksort(a,q+1,r);
	}
}




int main()
{
	int n,i;
	printf("enter the num of elements");
	scanf("%d",&n);

	int a[n];
	printf("enter the array elements");
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}

	quicksort(a,0,n-1);

	printf("sorted array");
	for(i=0;i<n;i++)
	{
		printf("%d",a[i]);
		printf("\n");
	}
	return 0;
}

